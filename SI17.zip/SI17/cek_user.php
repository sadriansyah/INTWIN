<?php
session_start();
include 'config/connect.php';

$username = $_POST['username'];
$password = $_POST['password'];

$login = mysqli_query($db,"SELECT*FROM akun WHERE username='$username' and password='$password'");
$cek = mysqli_num_rows($login);

if($cek>0){
  $data = mysqli_fetch_assoc($login);
  if($data['hak_akses']=='admin'){
    $_SESSION['nim']=$data['nim'];
    $_SESSION['nama'] = $data['username'];
    $_SESSION['hak_akses']='admin';
    header("Location: admin/index.php");
  }elseif ($data['hak_akses']=='user') {
    $_SESSION['nim']=$data['nim'];
    $_SESSION['nama'] = $data['username'];
    $_SESSION['hak_akses']='user';
    header("Location: user/index.php");
  }else {
    header("location: index.php?pesan=gagal");
  }

}else {
  header("location: index.php?pesan=gagal");
}

 ?>
