<?php
$host = "localhost";
$user = "root";
$pass = "";
$database = "inheritance";
 ?>
