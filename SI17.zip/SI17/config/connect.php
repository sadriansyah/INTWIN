<?php
 $db = new mysqli("localhost","root","","inheritance");
 if(!$db){
   echo "koneksi gagal";
 }

 ?>
