<?php
ob_start();
require_once('../config/koneksi.php');
require_once('../config/database.php');
include "admin.php";
$koneksi = new Database($host,$user,$pass,$database);
$mn = new Menu($koneksi);
$data = new Admin($koneksi);


$nm_foto = $mn->tampil($_GET['id'])->fetch_object()->foto;
unlink("../images/data-si/".$nm_foto);
$nim = $_GET['id'];
$data->hapus($_GET['id']);
header("Location: ../admin/layout/data_si.php");
exit();



 ?>
