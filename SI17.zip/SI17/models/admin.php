<?php
  include 'kebutuhanAdmin.php';
  include 'Menu.php';
  class Admin extends Menu implements kebutuhanAdmin{
    private $mysqli;
    function __construct($conn){
    $this->mysqli = $conn;
    }

    public function tambah($nama, $nim, $tgl, $noTelp, $email, $alamatAsal, $alamatBpp, $status, $foto){
      $db = $this->mysqli->conn;
      $db->query("INSERT INTO mahasiswa VALUES ('$nama', '$nim', '$tgl', '$noTelp', '$email', '$alamatAsal', '$alamatBpp',  '$status','$foto')") or die ($db->error);
    }
    public function edit($nama, $nim, $tgl, $noTelp, $email, $alamatAsal, $alamatBpp, $status, $foto,$var){
      $db = $this->mysqli->conn;
      $db->query("UPDATE mahasiswa SET nama='$nama', NIM='$nim', ttl= '$tgl', no_hp='$noTelp', email='$email', alamat_asal='$alamatAsal', alamat_bpp ='$alamatBpp', status='$status', foto='$nm_foto' WHERE NIM= '$var'");
    }
    public function uploadBerkas($nama,$file,$ekstensi){
      $db=$this->mysqli->conn;
      $db->query("INSERT INTO berkas VALUES(null,'$nama','$file','$ekstensi')");
    }
    public function hapusBerkas($id){
      $db=$this->mysqli->conn;
      $db->query("DELETE FROM berkas WHERE id_berkas='$id'");
    }
    public function hapus($id){
      $db=$this->mysqli->conn;
      $db->query("DELETE FROM mahasiswa Where NIM='$id'");
    }
    public function tampilPosting($id=null){
      $db = $this->mysqli->conn;
      $sql = "SELECT id_feed,nama, caption, gambar FROM feed,mahasiswa WHERE feed.nim = mahasiswa.NIM ";
      if($id != null){
        $sql.=" and id_feed=$id";
      }
      $query = $db->query($sql) or die ($db->error);
      return $query;

    }
    public function tampilBerkas($id = null){
      $db = $this->mysqli->conn;
      $sql = "SELECT*FROM berkas";
      if($id !=null){
        $sql.=" WHERE id_berkas $id";
      }
      $query = $db->query($sql) or die ($db->error);
      return $query;
    }
    public function hapusPosting($id){
      $db=$this->mysqli->conn;
      $db->query("DELETE FROM feed Where id_feed='$id'");
    }

    function __destruct(){
      $db = $this->mysqli->conn;
      $db->close();
    }
  }

  ?>
