<?php
/**
 *
 */
interface kebutuhanUser
{
  public function tambahPosting($nim,$caption,$foto);
  public function tampilPosting();
}


 ?>
