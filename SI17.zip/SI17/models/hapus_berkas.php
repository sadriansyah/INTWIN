<?php
ob_start();
require_once('../config/koneksi.php');
require_once('../config/database.php');
include "admin.php";
$koneksi = new Database($host,$user,$pass,$database);
$mn = new Menu($koneksi);
$data = new Admin($koneksi);

$nm_file=$_GET['ff'];
unlink("../file/".$nm_file);
$id = $_GET['id'];
$data->hapusBerkas($_GET['id']);
header("Location: ../admin/index.php");
exit();



 ?>
