<?php
include 'Menu.php';
include 'kebutuhanUser.php';
class user extends Menu implements kebutuhanUser{
  private $mysqli;
  private $idPosting;
  private $nim;
  private $caption;
  private $foto;

  function __construct($conn){
  $this->mysqli = $conn;
  }
  function setNim($nim){
    $this->nim;
  }
  function setCaption($caption){
    $this->caption;
  }
  function setFoto($foto){
    $this->foto;
  }


  public function tampilPosting(){
    $db = $this->mysqli->conn;
    $sql = "SELECT id_feed,nama, caption, gambar FROM feed,mahasiswa WHERE feed.nim = mahasiswa.NIM ORDER BY id_feed DESC";
    $query = $db->query($sql) or die ($db->error);
    return $query;

  }
  public function tambahPosting($nim,$caption,$foto){
    $db=$this->mysqli->conn;
    $db->query("INSERT INTO feed VALUES (null, '$nim','$caption','$foto')") or die ($db->error);
  }


}
?>
