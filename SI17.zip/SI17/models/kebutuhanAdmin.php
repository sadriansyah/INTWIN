<?php
interface kebutuhanAdmin{
  public function tambah($nama, $nim, $tgl, $noTelp, $email, $alamatAsal, $alamatBpp, $status, $foto);
  public function edit($nama, $nim, $tgl, $noTelp, $email, $alamatAsal, $alamatBpp, $status, $foto,$var);
  public function uploadBerkas($nama,$file,$ekstensi);
  public function hapusBerkas($id);
  public function hapus($nim);
  public function tampilPosting($id);
  public function hapusPosting($id);

}

 ?>
