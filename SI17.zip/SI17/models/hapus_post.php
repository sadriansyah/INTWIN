<?php
ob_start();
require_once('../config/koneksi.php');
require_once('../config/database.php');
include "admin.php";
$koneksi = new Database($host,$user,$pass,$database);
$mn = new Menu($koneksi);
$data = new Admin($koneksi);

$nm_foto=$_GET['act'];
unlink("../images/".$nm_foto);
$id = $_GET['id'];
$data->hapusPosting($_GET['id']);
header("Location: ../admin/index.php");
exit();



 ?>
