<?php
class Menu {
  //mahasiswa
  private $mysqli;
  private $nama;
  private $nim;
  private $tgl;
  private $noTelp;
  private $email;
  private $alamatAsal;
  private $alamatBpp;
  private $status;
  private $foto;
  //album
  private $judul;
  private $jenis;
  private $gambar;

  function __construct($conn){
  $this->mysqli = $conn;
}

  function tampil($nim = null){
    $db = $this->mysqli->conn;
    $sql = "SELECT*FROM mahasiswa";
    if($nim !=null){
      $sql.=" WHERE NIM = $nim";
    }
    $query = $db->query($sql) or die ($db->error);
    return $query;
  }
  
  function tampilAlbum($id=null){
  $db = $this->mysqli->conn;
  $sql = "SELECT*FROM album";
  if($id !=null){
    $sql.=" WHERE id_album = $id";
  }
  $query = $db->query($sql) or die ($db->error);
  return $query;
}

function setFoto($foto){
  $this->foto;
}
  function setJudul($judul){
    $this->judul;
  }
  function setJenis($jenis){
    $this->jenis;
  }
  function setGambar($gambar){
    $this->gambar;
  }
  function getJudul(){
    return $this->judul;
  }
  function getJenis(){
    return $this->jenis;
  }
  function getGambar(){
    return $this->gambar;
  }
  function getFoto(){
    return $this->foto;
  }

  function uploadFoto($judul,$jenis,$gambar){
    $db=$this->mysqli->conn;
    $db->query("INSERT INTO album VALUES (null, '$judul','$jenis','$gambar')") or die ($db->error);
  }

}

 ?>
