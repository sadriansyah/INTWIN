-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 20 Bulan Mei 2019 pada 10.19
-- Versi server: 10.1.35-MariaDB
-- Versi PHP: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inheritance`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `akun`
--

CREATE TABLE `akun` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `hak_akses` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `nim` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `akun`
--

INSERT INTO `akun` (`username`, `password`, `hak_akses`, `email`, `nim`) VALUES
('admin', 'admin', 'admin', 'admin@gmail.com', '10171069'),
('rahmaths', '10171059', 'user', 'rahmaths@gmail.com', '10171059'),
('', '12345', 'user', 'sadrydoy@gmail.com', '10171069'),
('sadriansyah', '12345', 'user', 'sadrydoy@gmail.com', '10171069');

-- --------------------------------------------------------

--
-- Struktur dari tabel `album`
--

CREATE TABLE `album` (
  `id_album` int(11) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `jenis_album` varchar(100) NOT NULL,
  `fotoAlbum` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `album`
--

INSERT INTO `album` (`id_album`, `judul`, `jenis_album`, `fotoAlbum`) VALUES
(2, 'Foto Kita', 'Album SI17', 'SI171557848719.jpg'),
(3, 'Wawa', 'Organisasi', 'SI171557848740.jpg'),
(8, 'yoii', 'Organisasi', 'SI171557850943.jpg'),
(9, 'endah', 'Dokumentasi', 'SI171557864835.jpg'),
(10, 'adas', 'Organisasi', 'SI171557864858.jpg'),
(11, 'Foto kenangan', 'Dokumentasi', 'SI171557943456.jpg'),
(12, 'Foto Dokumentasi', 'Dokumentasi', 'SI171557945813.jpg'),
(13, 'Foto SI', 'Dokumentasi', 'SI171557986061.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `berkas`
--

CREATE TABLE `berkas` (
  `id_berkas` int(11) NOT NULL,
  `namaBerkas` varchar(100) NOT NULL,
  `file` varchar(100) NOT NULL,
  `ekstensi` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `berkas`
--

INSERT INTO `berkas` (`id_berkas`, `namaBerkas`, `file`, `ekstensi`) VALUES
(2, 'PDF Laporan Basdat 4', 'FILE1557956941.pdf', 'Array'),
(3, 'Laporan Basdat 2', 'FILE1557957109.pdf', '.pdf'),
(4, 'TP2 PSO', 'FILE1557957179.pdf', '.pdf');

-- --------------------------------------------------------

--
-- Struktur dari tabel `feed`
--

CREATE TABLE `feed` (
  `id_feed` int(11) NOT NULL,
  `nim` varchar(100) NOT NULL,
  `caption` varchar(100) NOT NULL,
  `gambar` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `feed`
--

INSERT INTO `feed` (`id_feed`, `nim`, `caption`, `gambar`) VALUES
(3, '10171069', 'Mantap djiwaaa', 'POST1557894247.jpg'),
(4, '10171069', 'ini adalah energi terbaru', 'POST1557904599.jpg'),
(5, '10171069', 'weh ada yang baru nih.. lihat luar biasa sekali penampilan dari Layout desain ini', 'POST1557908913.jpg'),
(10, '10171069', 'Baju Keren nih guys siapa tau mau buat untuk angkatan kita..!', 'POST1557982251.jpg'),
(11, '10171069', 'Karimun Jawa luar biasa', 'POST1557985976.jpg'),
(12, '10171069', 'Ini muka irfani', 'POST1558167850.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `nama` varchar(50) NOT NULL,
  `NIM` varchar(8) NOT NULL,
  `ttl` date NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `alamat_asal` varchar(100) NOT NULL,
  `alamat_bpp` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL,
  `foto` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mahasiswa`
--

INSERT INTO `mahasiswa` (`nama`, `NIM`, `ttl`, `no_hp`, `email`, `alamat_asal`, `alamat_bpp`, `status`, `foto`) VALUES
('Sadriansyah', '10171069', '1199-12-02', '130201192', 'sada@gmail.com', 'Penajam Paser Utara', 'JL KM 14 Karang Joang', 'Aktif Berkuliah', 'SI171557909815.jpg'),
('Rahmat Hardiansyah', '10171059', '1999-12-12', '1312313', 'rahmaths@gmail.com', 'Balikpapan Timur, Pandan Sari', 'Balikpapan Timur, Pandan Sari', 'Aktif Berkuliah', 'SI171557951119.jpg');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`id_album`);

--
-- Indeks untuk tabel `berkas`
--
ALTER TABLE `berkas`
  ADD PRIMARY KEY (`id_berkas`);

--
-- Indeks untuk tabel `feed`
--
ALTER TABLE `feed`
  ADD PRIMARY KEY (`id_feed`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `album`
--
ALTER TABLE `album`
  MODIFY `id_album` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `berkas`
--
ALTER TABLE `berkas`
  MODIFY `id_berkas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `feed`
--
ALTER TABLE `feed`
  MODIFY `id_feed` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
