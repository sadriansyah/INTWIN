<?php
ob_start();
require_once('../../config/koneksi.php');
require_once('../../config/database.php');
include "../../models/user.php";
$koneksi = new Database($host,$user,$pass,$database);
$data = new Menu($koneksi);

 ?>
<!DOCTYPE html>
<html lang="en" data-textdirection="ltr" class="loading">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Robust admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
    <meta name="keywords" content="admin template, robust admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="PIXINVENT">
    <title>INTWIN | Admin</title>
    <link rel="apple-touch-icon" sizes="60x60" href="../../app-assets/images/ico/apple-icon-60.png">
    <link rel="apple-touch-icon" sizes="76x76" href="../../app-assets/images/ico/apple-icon-76.png">
    <link rel="apple-touch-icon" sizes="120x120" href="../../app-assets/images/ico/apple-icon-120.png">
    <link rel="apple-touch-icon" sizes="152x152" href="../../app-assets/images/ico/apple-icon-152.png">
    <link rel="shortcut icon" type="image/x-icon" href="../../app-assets/images/ico/favicon.ico">
    <link rel="shortcut icon" type="image/png" href="../../app-assets/images/ico/favicon-32.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/bootstrap.css">
    <!-- font icons-->
    <link rel="stylesheet" type="text/css" href="../../app-assets/fonts/icomoon.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/vendors/css/extensions/pace.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/vendors/js/gallery/photo-swipe/photoswipe.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/vendors/js/gallery/photo-swipe/default-skin/default-skin.css">
    <!-- END VENDOR CSS-->
    <!-- BEGIN ROBUST CSS-->
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/bootstrap-extended.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/app.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/colors.css">
    <!-- END ROBUST CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/core/menu/menu-types/vertical-menu.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/core/menu/menu-types/vertical-overlay-menu.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/pages/gallery.css">
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <link rel="stylesheet" type="text/css" href="../../assets/css/style.css">
    <!-- END Custom CSS-->
  </head>
  <body data-open="click" data-menu="vertical-menu" data-col="2-columns" class="vertical-layout vertical-menu 2-columns  fixed-navbar">

    <!-- navbar-fixed-top-->
    <nav class="header-navbar navbar navbar-with-menu navbar-fixed-top navbar-semi-dark navbar-shadow">
      <div class="navbar-wrapper">
        <div class="navbar-header">
          <ul class="nav navbar-nav">
            <li class="nav-item mobile-menu hidden-md-up float-xs-left"><a class="nav-link nav-menu-main menu-toggle hidden-xs"><i class="icon-menu5 font-large-1"></i></a></li>
            <li class="nav-item"><a href="../index.php" class="navbar-brand nav-link"><img alt="branding logo" src="../../app-assets/images/logo/logo1.png" data-expand="../../app-assets/images/logo/logo1.png" data-collapse="../../app-assets/images/logo/t-icon.png" class="brand-logo"></a></li>
            <li class="nav-item hidden-md-up float-xs-right"><a data-toggle="collapse" data-target="#navbar-mobile" class="nav-link open-navbar-container"><i class="icon-ellipsis pe-2x icon-icon-rotate-right-right"></i></a></li>
          </ul>
        </div>
        <div class="navbar-container content container-fluid">
          <div id="navbar-mobile" class="collapse navbar-toggleable-sm">
            <ul class="nav navbar-nav">
              <li class="nav-item hidden-sm-down"><a class="nav-link nav-menu-main menu-toggle hidden-xs"><i class="icon-menu5"></i></a></li >
            </ul>
            <ul class="nav navbar-nav float-xs-right">
              <li class="dropdown dropdown-user nav-item"><a href="#" data-toggle="dropdown" class="dropdown-toggle nav-link dropdown-user-link"><span class="avatar avatar-online"><img src="../../app-assets/images/portrait/small/avatar-s-1.png" alt="avatar"><i></i></span><span class="user-name">Admin</span></a>
                <div class="dropdown-menu dropdown-menu-right"><a href="#" class="dropdown-item"><i class="icon-head"></i> Edit Profile</a><a href="#" class="dropdown-item"><i class="icon-profile"></i> My Profile</a>
                  <div class="dropdown-divider"></div><a href="logout.php" class="dropdown-item"><i class="icon-power3"></i> Logout</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>

    <!-- ////////////////////////////////////////////////////////////////////////////-->


    <!-- main menu-->
    <div data-scroll-to-active="true" class="main-menu menu-fixed menu-dark menu-accordion menu-shadow">
      <!-- main menu header-->
      <div class="main-menu-header">
        <input type="text" placeholder="Search" class="menu-search form-control round"/>
      </div>
      <!-- / main menu header-->
      <!-- main menu content-->
      <div class="main-menu-content">
        <ul id="main-menu-navigation" data-menu="menu-navigation" class="navigation navigation-main">
          <li class=" nav-item"><a href="../index.php"><i class="icon-home3"></i><span data-i18n="nav.dash.main" class="menu-title">Home</span></a>
          </li>
          <li class=" nav-item"><a href="data_si.php"><i class="icon-ios-people-outline"></i><span data-i18n="nav.cards.main" class="menu-title">SI17 Squad </span></a>
          </li>
          <li class=" nav-item"><a href="gallery-grid.php"><i class="icon-ios-albums-outline"></i><span data-i18n="nav.cards.main" class="menu-title">Album SI 17</span></a>
          </li>
          <li class=" nav-item"><a href="tambah_mahasiswa.php"><i class="icon-paper"></i><span data-i18n="nav.form_layouts.form_layout_basic" class="menu-title">Tambah Anggota</span></a>
          </li>
        </ul>
      </div>
      <!-- /main menu content-->
      <!-- main menu footer-->
      <!-- include includes/menu-footer-->
      <!-- main menu footer-->
    </div>
    <!-- / main menu-->

    <div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-xs-12 mb-1">
            <h2 class="content-header-title">Album SI17 </h2>
          </div>
          <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-xs-12">
            <div class="breadcrumb-wrapper col-xs-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="../index.php">Home</a>
                </li>
                <li class="breadcrumb-item active">Album SI17
                </li>
              </ol>
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Description -->
<section id="description" class="card">
    <div class="card-header">
      <h4 class="card-title">Album</h4>
      <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
        <div class="heading-elements">
            <ul class="list-inline mb-0">
                <li><a data-action="reload"><i class="icon-reload"></i></a></li>
                <li><a data-action="close"><i class="icon-cross2"></i></a></li>
            </ul>
        </div>
    </div>
    <div class="card-body collapse in">
      <div class="card-block">
          <div class="card-text">
            <a href="#"><button class="btn btn-info" type="button" data-target="#ModalAdd" data-toggle="modal"><i class="icon-plus"></i> Tambah Foto</button></a>
          </br><br/><p>Album SI17 berisi data-data dokumentasi SI17 beserta berkas-berkas yang biasanya dibutuhkan oleh mahasiswa terkhususnya SI17.</p>
              <p>Mohon untuk tidak mengupload foto maupun dokumentasi yang bersifat menyinggung, tidak baik dan sara.</p>
          </div>
      </div>
    </div>
</section>
<!--/ Description -->
<!-- Modal Popup Untuk Tambah Data Dosen -->
<div id="ModalAdd" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Upload Foto</h4>
      </div>
      <div class="modal-body">
        <form action="" name="modal_popup" enctype="multipart/form-data" method="post">
          <div class="form-group">
            <label>Judul Foto</label>
              <div class="input-group">
                <div class="input-group-addon">
                  <i class="icon-image"></i>
                </div>
                <input name="judul" type="text" class="form-control" placeholder="Masukkan judul" required=""/>
              </div>
          </div>
          <div class="form-group">
            <label>Jenis Foto</label>
              <div class="input-group">
                <div class="input-group-addon">
                  <i class="icon-android-arrow-dropdown"></i>
                </div>
                <select name="album" class="form-control" required="">
                  <option selected>Album SI17</option>
                  <option value="Organisasi">Organisasi</option>
                  <option value="Dokumentasi">Dokumentasi</option>
                </select>
              </div>
          </div>
          <div class="form-group">
            <input type="file" class="form-control" required="" name="foto" accept="image/jpeg">
          </div>
          <div class="modal-footer">
            <button class="btn btn-success" name="tambah" value="simpan">
              Tambah
            </button>
            <button type="reset" class="btn btn-danger"  data-dismiss="modal" aria-hidden="true">
              Batal
            </button>
          </div>
        </form>
        <?php

        if(@$_POST['tambah']){
          $judul = $koneksi->conn->real_escape_string($_POST['judul']);
          $album = $koneksi->conn->real_escape_string($_POST['album']);
          $data->setJudul($judul);
          $data->setJenis($album);

          $ekstensi = explode(".",$_FILES['foto']['name']);
          $nm_foto = "SI17".round(microtime(true)).".".end($ekstensi);
          $sumber = $_FILES['foto']['tmp_name'];
          $upload = move_uploaded_file($sumber,"../../images/".$nm_foto);
          $data->setGambar($nm_foto);
          if($upload){
            $data->uploadFoto($judul,$album,$nm_foto);
          }
        }


         ?>

      </div>
    </div>
  </div>
</div>
<!-- Image grid -->
<section id="image-gallery" class="card">
  <div class="card-header">
    <h4 class="card-title">Album</h4>
    <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
        <div class="heading-elements">
          <ul class="list-inline mb-0">
              <li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
              <li><a data-action="reload"><i class="icon-reload"></i></a></li>
              <li><a data-action="expand"><i class="icon-expand2"></i></a></li>
              <li><a data-action="close"><i class="icon-cross2"></i></a></li>
          </ul>
      </div>
  </div>
  <div class="card-body collapse in">
      <div class="card-block">
          <div class="card-text">
            <div class="col-md-1" >
                  <h2>Search</h2>
            </div>
            <div class="col-md-11">
            <input class="form-control" type="text" placeholder="" name="search">
          </div>
            </div>
      </div>
    <div class="card-block  my-gallery" itemscope itemtype="http://schema.org/ImageGallery">
      <div class="row">
        <?php
          $tampil =  $data->tampilAlbum();
          while($data = $tampil->fetch_object()){

         ?>
        <figure class="col-lg-3 col-md-6 col-xs-12" itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject">
          <a href="../../images/<?= $data->fotoAlbum;?>" itemprop="contentUrl" data-size="480x360">
              <img style="height:250px;width:250px;" class="img-thumbnail img-fluid" src="../../images/<?= $data->fotoAlbum ; ?>" itemprop="thumbnail" alt="Image description" />
          </a>
          <label><?= $data->fotoAlbum ; ?></label>
        </figure>
      <?php } ?>
  </div>
    </div>
    <!--/ Image grid -->

    <!-- Root element of PhotoSwipe. Must have class pswp. -->
    <div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">

        <!-- Background of PhotoSwipe.
             It's a separate element as animating opacity is faster than rgba(). -->
        <div class="pswp__bg"></div>

        <!-- Slides wrapper with overflow:hidden. -->
        <div class="pswp__scroll-wrap">

            <!-- Container that holds slides.
                PhotoSwipe keeps only 3 of them in the DOM to save memory.
                Don't modify these 3 pswp__item elements, data is added later on. -->
            <div class="pswp__container">
                <div class="pswp__item"></div>
                <div class="pswp__item"></div>
                <div class="pswp__item"></div>
            </div>

            <!-- Default (PhotoSwipeUI_Default) interface on top of sliding area. Can be changed. -->
            <div class="pswp__ui pswp__ui--hidden">

                <div class="pswp__top-bar">

                    <!--  Controls are self-explanatory. Order can be changed. -->

                    <div class="pswp__counter"></div>

                    <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>

                    <button class="pswp__button pswp__button--share" title="Share"></button>

                    <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>

                    <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>

                    <!-- Preloader demo http://codepen.io/dimsemenov/pen/yyBWoR -->
                    <!-- element will get class pswp__preloader-active when preloader is running -->
                    <div class="pswp__preloader">
                        <div class="pswp__preloader__icn">
                          <div class="pswp__preloader__cut">
                            <div class="pswp__preloader__donut"></div>
                          </div>
                        </div>
                    </div>
                </div>

                <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
                    <div class="pswp__share-tooltip"></div>
                </div>

                <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)">
                </button>

                <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)">
                </button>

                <div class="pswp__caption">
                    <div class="pswp__caption__center"></div>
                </div>

            </div>

        </div>
    </div>
  </div>
  <!--/ PhotoSwipe -->
</section>
<!--/ Image grid -->
        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->


    <footer class="footer footer-static footer-light navbar-border">
      <p class="clearfix text-muted text-sm-center mb-0 px-2"><span class="float-md-left d-xs-block d-md-inline-block">Copyright  &copy; 2019 <a href="../../about.php" target="_blank" class="text-bold-800 grey darken-2">INTWIN </a>, All rights reserved. </span><span class="float-md-right d-xs-block d-md-inline-block">SISTEM INFORMASI 2017 <i class="icon-heart5 pink"></i></span></p>
    </footer>

    <!-- BEGIN VENDOR JS-->
    <script src="../../app-assets/js/core/libraries/jquery.min.js" type="text/javascript"></script>
    <script src="../../app-assets/vendors/js/ui/tether.min.js" type="text/javascript"></script>
    <script src="../../app-assets/js/core/libraries/bootstrap.min.js" type="text/javascript"></script>
    <script src="../../app-assets/vendors/js/ui/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
    <script src="../../app-assets/vendors/js/ui/unison.min.js" type="text/javascript"></script>
    <script src="../../app-assets/vendors/js/ui/blockUI.min.js" type="text/javascript"></script>
    <script src="../../app-assets/vendors/js/ui/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script src=".././app-assets/vendors/js/ui/screenfull.min.js" type="text/javascript"></script>
    <script src="../../app-assets/vendors/js/extensions/pace.min.js" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN ROBUST JS-->
    <script src="../../app-assets/js/core/app-menu.js" type="text/javascript"></script>
    <script src="../../app-assets/js/core/app.js" type="text/javascript"></script>
    <!-- END ROBUST JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <!-- END PAGE LEVEL JS-->
  </body>
</html>
