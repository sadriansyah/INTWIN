<?php
ob_start();
require_once('../../config/koneksi.php');
require_once('../../config/database.php');
include "../../models/admin.php";
$koneksi = new Database($host,$user,$pass,$database);
$data = new Menu($koneksi);
$adm = new Admin($koneksi)

 ?>
<!DOCTYPE html>
<html lang="en" data-textdirection="ltr" class="loading">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Robust admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
    <meta name="keywords" content="admin template, robust admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="PIXINVENT">
    <title>INTWIN | Admin </title>
    <link rel="apple-touch-icon" sizes="60x60" href="../../app-assets/images/ico/apple-icon-60.png">
    <link rel="apple-touch-icon" sizes="76x76" href="../../app-assets/images/ico/apple-icon-76.png">
    <link rel="apple-touch-icon" sizes="120x120" href="../../app-assets/images/ico/apple-icon-120.png">
    <link rel="apple-touch-icon" sizes="152x152" href="../../app-assets/images/ico/apple-icon-152.png">
    <link rel="shortcut icon" type="image/x-icon" href="../../app-assets/images/ico/favicon.ico">
    <link rel="shortcut icon" type="image/png" href="../../app-assets/images/ico/favicon-32.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/bootstrap.css">
    <!-- font icons-->
    <link rel="stylesheet" type="text/css" href="../../app-assets/fonts/icomoon.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/vendors/css/extensions/pace.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/vendors/js/gallery/photo-swipe/photoswipe.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/vendors/js/gallery/photo-swipe/default-skin/default-skin.css">
    <!-- END VENDOR CSS-->
    <!-- BEGIN ROBUST CSS-->
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/bootstrap-extended.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/app.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/colors.css">
    <!-- END ROBUST CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/core/menu/menu-types/vertical-menu.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/core/menu/menu-types/vertical-overlay-menu.css">
    <link rel="stylesheet" type="text/css" href="../../app-assets/css/pages/gallery.css">
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <link rel="stylesheet" type="text/css" href="../../assets/css/style.css">
    <!-- END Custom CSS-->
  </head>
  <body data-open="click" data-menu="vertical-menu" data-col="2-columns" class="vertical-layout vertical-menu 2-columns  fixed-navbar">

    <!-- navbar-fixed-top-->
    <nav class="header-navbar navbar navbar-with-menu navbar-fixed-top navbar-semi-dark navbar-shadow">
      <div class="navbar-wrapper">
        <div class="navbar-header">
          <ul class="nav navbar-nav">
            <li class="nav-item mobile-menu hidden-md-up float-xs-left"><a class="nav-link nav-menu-main menu-toggle hidden-xs"><i class="icon-menu5 font-large-1"></i></a></li>
            <li class="nav-item"><a href="../index.php" class="navbar-brand nav-link"><img alt="branding logo" src="../../app-assets/images/logo/logo1.png" data-expand="../../app-assets/images/logo/logo1.png" data-collapse="../../app-assets/images/logo/t-icon.png" class="brand-logo"></a></li>
            <li class="nav-item hidden-md-up float-xs-right"><a data-toggle="collapse" data-target="#navbar-mobile" class="nav-link open-navbar-container"><i class="icon-ellipsis pe-2x icon-icon-rotate-right-right"></i></a></li>
          </ul>
        </div>
        <div class="navbar-container content container-fluid">
          <div id="navbar-mobile" class="collapse navbar-toggleable-sm">
            <ul class="nav navbar-nav">
              <li class="nav-item hidden-sm-down"><a class="nav-link nav-menu-main menu-toggle hidden-xs"><i class="icon-menu5"></i></a></li >
            </ul>
            <ul class="nav navbar-nav float-xs-right">
              <li class="dropdown dropdown-user nav-item"><a href="#" data-toggle="dropdown" class="dropdown-toggle nav-link dropdown-user-link"><span class="avatar avatar-online"><img src="../../app-assets/images/portrait/small/avatar-s-1.png" alt="avatar"><i></i></span><span class="user-name">Admin</span></a>
                <div class="dropdown-menu dropdown-menu-right"><a href="#" class="dropdown-item"><i class="icon-head"></i> Edit Profile</a><a href="#" class="dropdown-item"><i class="icon-profile"></i> My Profile</a>
                  <div class="dropdown-divider"></div><a href="logout.php" class="dropdown-item"><i class="icon-power3"></i> Logout</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>

    <!-- ////////////////////////////////////////////////////////////////////////////-->


    <!-- main menu-->
    <div data-scroll-to-active="true" class="main-menu menu-fixed menu-dark menu-accordion menu-shadow">
      <!-- main menu header-->
      <div class="main-menu-header">
        <input type="text" placeholder="Search" class="menu-search form-control round"/>
      </div>
      <!-- / main menu header-->
      <!-- main menu content-->
      <div class="main-menu-content">
        <ul id="main-menu-navigation" data-menu="menu-navigation" class="navigation navigation-main">
          <li class=" nav-item"><a href="../index.php"><i class="icon-home3"></i><span data-i18n="nav.dash.main" class="menu-title">Home</span></a>
          </li>
          <li class=" nav-item"><a href="data_si.php"><i class="icon-ios-people-outline"></i><span data-i18n="nav.cards.main" class="menu-title">SI17 Squad </span></a>
          </li>
          <li class=" nav-item"><a href="gallery-grid.php"><i class="icon-ios-albums-outline"></i><span data-i18n="nav.cards.main" class="menu-title">Album SI 17</span></a>
          </li>
          <li class=" nav-item"><a href="tambah_mahasiswa.php"><i class="icon-paper"></i><span data-i18n="nav.form_layouts.form_layout_basic" class="menu-title">Tambah Anggota</span></a>
          </li>
        </ul>
      </div>
      <!-- /main menu content-->
      <!-- main menu footer-->
      <!-- include includes/menu-footer-->
      <!-- main menu footer-->
    </div>
    <!-- / main menu-->

    <div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-xs-12 mb-1">
            <h2 class="content-header-title">Form Edit Data </h2>
          </div>
          <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-xs-12">
            <div class="breadcrumb-wrapper col-xs-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="../index.php">Home</a>
                </li>
                <li class="breadcrumb-item active">Edit Data
                </li>
              </ol>
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Description -->
          <section id="basic-form-layouts">
            <?php
            $nim = $_GET['id'];
            $tampil= $data->tampil($nim);
            while($data = $tampil->fetch_object()){
             ?>
          	<div class="row match-height">
          		<div class="col-md-12">
          			<div class="card">
          				<div class="card-header">
          					<h4 class="card-title" id="basic-layout-form-center">Sistem Informasi</h4>
          					<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
          					<div class="heading-elements">
          						<ul class="list-inline mb-0">
          							<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
          							<li><a data-action="reload"><i class="icon-reload"></i></a></li>
          							<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
          							<li><a data-action="close"><i class="icon-cross2"></i></a></li>
          						</ul>
          					</div>
          				</div>
          				<div class="card-body collapse in">
          					<div class="card-block">
          						<form class="form" action="" method="post" enctype="multipart/form-data">
          							<div class="row">
          								<div class="col-md-6 offset-md-3">
          									<div class="form-body">
          										<div class="form-group">
          											<label for="eventInput1">Nama </label>
                                <input type="hidden" name="var" value="<?php $_GET['id']; ?>">
          											<input type="text" id="eventInput1" class="form-control" value="<?=$data->nama ?>" placeholder="name" name="nama">
          										</div>
          										<div class="form-group">
          											<label for="eventInput2">Nim</label>
          											<input type="text" id="eventInput2" class="form-control" placeholder="title" name="nim" value="<?=$data->NIM ?>">
          										</div>

          										<div class="form-group">
          											<label for="eventInput3">Tanggal Lahir</label>
          											<input type="date" id="eventInput3" class="form-control" placeholder="company" name="ttl" value="<?=$data->ttl ?>">
          										</div>

                              <div class="form-group">
          											<label for="eventInput4">Nomor Telepon</label>
          											<input type="text" id="eventInput4" class="form-control" placeholder="email" name="no_telp" value="<?=$data->no_hp ?>">
          										</div>

          										<div class="form-group">
          											<label for="eventInput4">Email</label>
          											<input type="email" id="eventInput4" class="form-control" placeholder="email" name="email" value="<?=$data->email ?>">
          										</div>

          										<div class="form-group">
          											<label for="eventInput5">Alamat Asal</label>
          											<input type="text" id="eventInput5" class="form-control" name="alamat_asal" placeholder="Alamat Asal" value="<?=$data->alamat_asal ?>">
          										</div>
                              <div class="form-group">
          											<label for="eventInput5">Alamat Dibalikpapan</label>
          											<input type="text" id="eventInput5" class="form-control" name="alamat_bpp" placeholder="contact number" value="<?=$data->alamat_bpp ?>">
          										</div>
                              <div class="form-group">
          											<label for="eventInput5">Status</label>
                                <select class="form-control" name='status'>
                                  <option value=""> - Pilih status - </option>
                                  <option value="Aktif Berkuliah">Aktif Berkuliah</option>
                                  <option value="Cuti">Cuti</option>
                                  <option value="Resign">Resign</option>
                                </select>
          										</div>
                              <div class="form-group">
          											<label for="eventInput5">Foto</label>
          											<input type="file" accept="image/jpeg" id="eventInput5" class="form-control" name="foto" placeholder="file">
          										</div>
          									</div>
          								</div>
          							</div>
          							<div class="form-actions center">
          								<button type="reset" class="btn btn-warning mr-1">
          									<i class="icon-cross2"></i> Reset
          								</button>
          								<button name="simpan" value="simpan" class="btn btn-primary">
          									<i class="icon-check2"></i> Simpan
          								</button>
          							</div>
          						</form>
                      <?php
                    }
                    if(@$_POST['simpan']){
                      include '../../config/connect.php';
                      $nama = $koneksi->conn->real_escape_string($_POST['nama']);
                      $nim = $koneksi->conn->real_escape_string($_POST['nim']);
                      $tgl = $koneksi->conn->real_escape_string($_POST['ttl']);
                      $noTelp = $koneksi->conn->real_escape_string($_POST['no_telp']);
                      $email = $koneksi->conn->real_escape_string($_POST['email']);
                      $alamatAsal = $koneksi->conn->real_escape_string($_POST['alamat_asal']);
                      $alamatBpp = $koneksi->conn->real_escape_string($_POST['alamat_bpp']);
                      $status = $koneksi->conn->real_escape_string($_POST['status']);
                      $var = $_GET['id'];
                      $ekstensi = explode(".",$_FILES['foto']['name']);
                      $nm_foto = "SI17".round(microtime(true)).".".end($ekstensi);
                      $sumber = $_FILES['foto']['tmp_name'];
                      $upload = move_uploaded_file($sumber,"../../images/data-diri/".$nm_foto);
                      if($upload){
                        $adm->edit($nama, $nim, $tgl, $noTelp, $email, $alamatAsal, $alamatBpp, $status, $foto, $nim);
                        header("Location: data_si.php");
                        exit();
                      }

                    }

                    ?>

          					</div>
          				</div>
          			</div>
          		</div>
          	</div>
          </section>
<!--/ Image grid -->
        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->


    <footer class="footer footer-static footer-light navbar-border">
      <p class="clearfix text-muted text-sm-center mb-0 px-2"><span class="float-md-left d-xs-block d-md-inline-block">Copyright  &copy; 2019 <a href="../../about.php" target="_blank" class="text-bold-800 grey darken-2">INTWIN </a>, All rights reserved. </span><span class="float-md-right d-xs-block d-md-inline-block">SISTEM INFORMASI 2017 <i class="icon-heart5 pink"></i></span></p>
    </footer>

    <!-- BEGIN VENDOR JS-->
    <script src="../../app-assets/js/core/libraries/jquery.min.js" type="text/javascript"></script>
    <script src="../../app-assets/vendors/js/ui/tether.min.js" type="text/javascript"></script>
    <script src="../../app-assets/js/core/libraries/bootstrap.min.js" type="text/javascript"></script>
    <script src="../../app-assets/vendors/js/ui/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
    <script src="../../app-assets/vendors/js/ui/unison.min.js" type="text/javascript"></script>
    <script src="../../app-assets/vendors/js/ui/blockUI.min.js" type="text/javascript"></script>
    <script src="../../app-assets/vendors/js/ui/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script src="../../app-assets/vendors/js/ui/screenfull.min.js" type="text/javascript"></script>
    <script src="../../app-assets/vendors/js/extensions/pace.min.js" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <script src="../../app-assets/vendors/js/gallery/masonry/masonry.pkgd.min.js" type="text/javascript"></script>
    <script src="../../app-assets/vendors/js/gallery/photo-swipe/photoswipe.min.js" type="text/javascript"></script>
    <script src="../../app-assets/vendors/js/gallery/photo-swipe/photoswipe-ui-default.min.js" type="text/javascript"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN ROBUST JS-->
    <script src="../../app-assets/js/core/app-menu.js" type="text/javascript"></script>
    <script src="../../app-assets/js/core/app.js" type="text/javascript"></script>
    <!-- END ROBUST JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <script src="../../app-assets/js/scripts/gallery/photo-swipe/photoswipe-script.js" type="text/javascript"></script>
    <!-- END PAGE LEVEL JS-->
  </body>
</html>
